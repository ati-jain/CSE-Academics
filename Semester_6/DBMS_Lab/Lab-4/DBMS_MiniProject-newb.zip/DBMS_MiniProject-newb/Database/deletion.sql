USE Hospital;

drop table if exists `Patient_Admission`;
drop table if exists `Patient_Appointment`;
drop table if exists `Prescription_Treatment`;
drop table if exists `Prescription_Test`;
drop table if exists `Appointment`;
drop table if exists `Prescription`;
drop table if exists `Admission`;
drop table if exists `Room`;
drop table if exists `User`;
drop table if exists `Test`;
drop table if exists `Patient`;
drop table if exists `Treatment`;

delete from `Patient_Admission`;
delete from `Patient_Appointment`;
delete from `Prescription_Treatment`;
delete from `Prescription_Test`;
delete from `Appointment`;
delete from `Prescription`;
delete from `Admission`;
delete from `Room`;
delete from `User`;
delete from `Test`;
delete from `Patient`;
delete from `Treatment`;



