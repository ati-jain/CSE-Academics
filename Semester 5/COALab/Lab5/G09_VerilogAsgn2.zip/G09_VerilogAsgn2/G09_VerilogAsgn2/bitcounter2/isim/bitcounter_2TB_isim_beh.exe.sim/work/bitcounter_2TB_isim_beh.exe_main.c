/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_14624587429475263438_2858095548_init();
    work_m_13128597800399415741_3996337969_init();
    work_m_17096212471520250382_1406143218_init();
    work_m_08371149256378907866_1279891299_init();
    work_m_09739010035565615263_1475887490_init();
    work_m_05599802383447998079_2936381558_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_05599802383447998079_2936381558");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
